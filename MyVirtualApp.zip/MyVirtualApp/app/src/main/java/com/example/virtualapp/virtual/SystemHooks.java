package com.example.virtualapp.virtual;

import android.os.Build;
import com.example.virtualapp.device.DeviceProfile;

public class SystemHooks {
    
    public static void hookBuildClass(DeviceProfile p) {
        try {
            Build.MODEL = p.getModel();
            Build.MANUFACTURER = p.getManufacturer();
            if (p.getFingerprint() != null && p.getFingerprint().getSystemFingerprint() != null) {
                Build.FINGERPRINT = p.getFingerprint().getSystemFingerprint();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void hookSystemProperties(DeviceProfile p) {
        // برای اندروید ۱۲ به بالا
    }

    public static void hookTelephonyManager(DeviceProfile p) {
        // برای جعل IMEI
    }

    public static void setCustomFingerprint(String fp, DeviceProfile p) {
        if (p.getFingerprint() != null) {
            p.getFingerprint().setSystemFingerprint(fp);
            hookBuildClass(p);
        }
    }

    public static void setCustomImei(String imei1, String imei2, DeviceProfile profile) {
        if (profile.getNetwork() != null) {
            if (imei1 != null && imei1.length() == 15 && imei1.matches("\\d+")) {
                profile.getNetwork().imei1 = imei1;
            }
            if (imei2 != null && imei2.length() == 15 && imei2.matches("\\d+")) {
                profile.getNetwork().imei2 = imei2;
            }
            hookTelephonyManager(profile);
        }
    }
}